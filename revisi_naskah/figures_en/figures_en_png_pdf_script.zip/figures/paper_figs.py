"""Paper-ready result figures (English, IEEE two-column sizes)."""
import numpy as np, matplotlib, os
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

OUT = os.path.dirname(os.path.abspath(__file__))
DAY, NIGHT, GREY, INK, GRID = "#B26A12", "#4A3DA6", "#9A9A9A", "#222222", "#DDDDDD"
DAY_L, NIGHT_L = "#E9C9A0", "#C9C3EC"
plt.rcParams.update({
    "font.family": "DejaVu Sans", "font.size": 8,
    "axes.labelsize": 8, "xtick.labelsize": 7.5, "ytick.labelsize": 7.5, "legend.fontsize": 7,
    "axes.edgecolor": "#555555", "axes.linewidth": 0.6, "xtick.color": INK, "ytick.color": INK,
    "axes.labelcolor": INK, "text.color": INK,
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    "savefig.dpi": 300, "savefig.bbox": "tight", "savefig.pad_inches": 0.02,
})
SINGLE, DOUBLE = 3.5, 7.16
EK = dict(ecolor=INK, lw=0.7, capsize=2, capthick=0.7)

def clean(ax, axis="y"):
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    ax.grid(True, axis=axis, color=GRID, lw=0.5, zorder=0)
    ax.set_axisbelow(True)
    ax.tick_params(length=2.5, width=0.5)

def save(fig, name):
    fig.savefig(f"{OUT}/{name}.png"); fig.savefig(f"{OUT}/{name}.pdf"); plt.close(fig)

# ------------------------------------------------------------------ Fig. 4
models = ["Teacher\nYOLOv8-L", "Student\nBaseline", "Student\nKD"]
day50, night50 = [0.5597, 0.4893, 0.5013], [0.5156, 0.4470, 0.4780]
derr, nerr = [0, 0, 0.0024], [0, 0, 0.0038]
gap = [0.0441, 0.0423, 0.0233]
fig, ax = plt.subplots(figsize=(SINGLE, 2.35))
x = np.arange(3); w = 0.34
ax.bar(x - w/2, day50, w, yerr=derr, color=DAY, label="Daytime", zorder=3, error_kw=EK)
ax.bar(x + w/2, night50, w, yerr=nerr, color=NIGHT, label="Nighttime", zorder=3, error_kw=EK)
for i in range(3):
    ax.text(x[i]-w/2, day50[i]+derr[i]+0.004, f"{day50[i]:.4f}", ha="center", va="bottom", fontsize=6.3, zorder=7)
    ax.text(x[i]+w/2, night50[i]+nerr[i]+0.004, f"{night50[i]:.4f}", ha="center", va="bottom", fontsize=6.3, zorder=7)
    ax.text(x[i], max(day50[i], night50[i]) + 0.030, f"gap {gap[i]:.4f}", ha="center", va="bottom", fontsize=6.8,
            fontweight="bold" if i == 2 else "normal")
ax.set_xticks(x); ax.set_xticklabels(models)
ax.set_ylim(0.40, 0.615); ax.set_ylabel("mAP@0.5")
ax.legend(frameon=False, loc="upper right", ncol=2, handlelength=1.2, columnspacing=1.0)
clean(ax); fig.tight_layout(); save(fig, "Fig4_map50_day_night")

# ------------------------------------------------------------------ Fig. 5
rel50, rel95 = [7.88, 8.65, 4.65], [13.55, 12.67, 8.75]
fig, ax = plt.subplots(figsize=(SINGLE, 2.2))
ax.bar(x - w/2, rel50, w, color="#555555", label="mAP@0.5", zorder=3)
ax.bar(x + w/2, rel95, w, color="#BBBBBB", label="mAP@0.5:0.95", zorder=3)
for i in range(3):
    ax.text(x[i]-w/2, rel50[i]+0.25, f"{rel50[i]:.2f}%", ha="center", va="bottom", fontsize=6.5)
    ax.text(x[i]+w/2, rel95[i]+0.25, f"{rel95[i]:.2f}%", ha="center", va="bottom", fontsize=6.5)
ax.set_xticks(x); ax.set_xticklabels(models)
ax.set_ylim(0, 16); ax.set_ylabel("Relative day-to-night drop (%)")
ax.legend(frameon=False, loc="upper right", handlelength=1.2)
clean(ax); fig.tight_layout(); save(fig, "Fig5_relative_drop")

# ------------------------------------------------------------------ Fig. 6
runs = {"Daytime mAP@0.5": ([0.5014, 0.4989, 0.5036], 0.5013, 0.0024, 0.4893, DAY),
        "Nighttime mAP@0.5": ([0.4740, 0.4816, 0.4783], 0.4780, 0.0038, 0.4470, NIGHT),
        "Day − night gap (mAP@0.5)": ([0.0274, 0.0173, 0.0253], 0.0233, 0.0053, 0.0423, "#555555")}
fig, axes = plt.subplots(1, 3, figsize=(DOUBLE, 2.15), gridspec_kw=dict(wspace=0.5))
for ax, (title, (vals, mean, sd, base, col)) in zip(axes, runs.items()):
    xr = np.arange(3)
    ax.axhspan(mean-sd, mean+sd, color=col, alpha=0.13, zorder=1, lw=0)
    ax.axhline(mean, color=col, lw=1.0, zorder=4)
    ax.axhline(base, color=INK, lw=0.8, ls=(0, (3, 2)), zorder=4)
    ax.scatter(xr, vals, s=22, color=col, zorder=5, edgecolor="white", lw=0.5)
    for i, v in enumerate(vals):
        ax.text(xr[i]+0.12, v, f"{v:.4f}", fontsize=6.2, va="center", ha="left", zorder=7)
    lo, hi = min(min(vals), base, mean-sd), max(max(vals), base, mean+sd)
    span = hi - lo
    ax.set_ylim(lo - 0.18*span, hi + 0.18*span)
    ax.set_xlim(-0.5, 2.9)
    ax.set_xticks(xr); ax.set_xticklabels(["Run 1", "Run 2", "Run 3"])
    ax.set_ylabel(title, fontsize=7.5)
    clean(ax)
handles = [Line2D([], [], marker="o", ls="", color="#555555", markersize=4, label="Student KD, single run"),
           Line2D([], [], color="#555555", lw=1.0, label="mean of 3 runs"),
           Patch(facecolor="#555555", alpha=0.13, label="mean ± 1 SD"),
           Line2D([], [], color=INK, lw=0.8, ls=(0, (3, 2)), label="Student Baseline")]
fig.subplots_adjust(left=0.09, right=0.99, top=0.97, bottom=0.27)
fig.legend(handles=handles, loc="lower center", ncol=4, frameon=False, bbox_to_anchor=(0.5, 0.0), handlelength=1.6)
save(fig, "Fig6_three_runs")

# ------------------------------------------------------------------ Fig. 7 (ablation, two variants)
def fig7(name, ncwd_day, ncwd_night, ncwd_rel):
    variants = ["No soft\nweighting", "No cosine\nschedule", "No CWD"]
    d_day = [0.4973-0.5013, 0.5107-0.5013, ncwd_day-0.5013]
    d_night = [0.4628-0.4780, 0.4716-0.4780, ncwd_night-0.4780]
    rel = [6.94, 7.66, ncwd_rel]
    fig, axes = plt.subplots(1, 2, figsize=(DOUBLE, 2.15), gridspec_kw=dict(wspace=0.32, width_ratios=[1, 1.15]))
    ax = axes[0]
    xa = np.arange(3); wa = 0.34
    ax.axhline(0, color=INK, lw=0.8, zorder=4)
    ax.axhspan(-0.0038, 0.0038, color="#000000", alpha=0.06, lw=0, zorder=1)
    ax.bar(xa - wa/2, d_day, wa, color=DAY, label="Daytime", zorder=3)
    ax.bar(xa + wa/2, d_night, wa, color=NIGHT, label="Nighttime", zorder=3)
    for i in range(3):
        for xx, v in ((xa[i]-wa/2, d_day[i]), (xa[i]+wa/2, d_night[i])):
            ax.text(xx, v + (0.0006 if v >= 0 else -0.0006), f"{v:+.4f}", ha="center",
                    va="bottom" if v >= 0 else "top", fontsize=6.2, zorder=7,
                    bbox=dict(fc="white", ec="none", pad=0.3, alpha=0.85))
    ax.set_xticks(xa); ax.set_xticklabels(variants)
    ax.set_ylim(-0.021, 0.016)
    ax.set_ylabel("Δ mAP@0.5 vs. full Student KD")
    ax.text(2.45, 0.0038, "±1 SD", fontsize=6, va="bottom", ha="right", color="#666666")
    ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2, handlelength=1.2, columnspacing=1.0)
    clean(ax)
    ax = axes[1]
    labels = ["Student\nBaseline", "No soft\nweighting", "No cosine\nschedule", "No CWD", "Full\nStudent KD"]
    vals = [8.65] + rel + [4.65]
    cols = [GREY, "#8C87B8", "#8C87B8", "#8C87B8", NIGHT]
    xb = np.arange(5)
    ax.bar(xb, vals, 0.6, color=cols, zorder=3)
    for i, v in enumerate(vals):
        ax.text(xb[i], v+0.15, f"{v:.2f}%", ha="center", va="bottom", fontsize=6.4,
                fontweight="bold" if i == 4 else "normal")
    ax.set_xticks(xb); ax.set_xticklabels(labels, fontsize=6.3)
    ax.set_ylim(0, 10.5); ax.set_ylabel("Relative day-to-night drop (%)")
    clean(ax)
    fig.tight_layout(); save(fig, name)

fig7("Fig7_ablation", 0.5010, 0.4744, 5.31)

# ------------------------------------------------------------------ Fig. 8 (5-fold)
fd = [0.5174, 0.5249, 0.5076, 0.5153, 0.5073]
fn = [0.4814, 0.4916, 0.4800, 0.4948, 0.4958]
frel = [6.96, 6.34, 5.44, 3.98, 2.27]
fig, axes = plt.subplots(1, 2, figsize=(DOUBLE, 2.1), gridspec_kw=dict(wspace=0.3))
ax = axes[0]
xf = np.arange(5); wf = 0.36
ax.bar(xf - wf/2, fd, wf, color=DAY, label="Daytime", zorder=3)
ax.bar(xf + wf/2, fn, wf, color=NIGHT, label="Nighttime", zorder=3)
for i in range(5):
    ax.text(xf[i]-wf/2, fd[i]+0.003, f"{fd[i]:.4f}", ha="center", va="bottom", fontsize=5.8, rotation=90)
    ax.text(xf[i]+wf/2, fn[i]+0.003, f"{fn[i]:.4f}", ha="center", va="bottom", fontsize=5.8, rotation=90)
ax.set_xticks(xf); ax.set_xticklabels([f"Fold {i}" for i in range(5)])
ax.set_ylim(0.44, 0.58); ax.set_ylabel("mAP@0.5")
ax.legend(frameon=False, loc="upper right", ncol=2, handlelength=1.2, columnspacing=1.0)
clean(ax)
ax = axes[1]
ax.bar(xf, frel, 0.55, color=NIGHT, zorder=3)
for i, v in enumerate(frel):
    ax.text(xf[i], v+0.15, f"{v:.2f}%", ha="center", va="bottom", fontsize=6.4)
ax.axhline(8.65, color=INK, lw=0.8, ls=(0, (3, 2)), zorder=4)
ax.text(4.35, 8.65+0.15, "Student Baseline 8.65%", ha="right", va="bottom", fontsize=6.4)
ax.axhline(5.00, color=NIGHT, lw=0.8, zorder=4)
ax.text(4.35, 5.00+0.15, "5-fold mean 5.00%", ha="right", va="bottom", fontsize=6.4, color=NIGHT)
ax.set_xticks(xf); ax.set_xticklabels([f"Fold {i}" for i in range(5)])
ax.set_ylim(0, 10.5); ax.set_ylabel("Relative day-to-night drop (%)")
clean(ax)
fig.tight_layout(); save(fig, "Fig8_five_fold")

# ------------------------------------------------------------------ Fig. 9 (per-class night gain)
cls = ["Bike", "Rider", "Motor", "Bus", "Traffic light", "Person", "Traffic sign", "Truck", "Car"]
gain = [0.1082, 0.1055, 0.0169, 0.0153, 0.0121, 0.0093, 0.0069, 0.0029, 0.0018]
vru = [True, True, True, False, False, True, False, False, False]
fig, ax = plt.subplots(figsize=(SINGLE, 2.5))
y = np.arange(9)[::-1]
ax.barh(y, gain, 0.62, color=[NIGHT if v else GREY for v in vru], zorder=3)
for yy, g in zip(y, gain):
    ax.text(g+0.002, yy, f"+{g:.4f}", va="center", ha="left", fontsize=6.4)
ax.set_yticks(y); ax.set_yticklabels(cls)
ax.set_xlim(0, 0.135); ax.set_xlabel("Nighttime AP@0.5 gain over Student Baseline")
ax.legend(handles=[Patch(facecolor=NIGHT, label="Vulnerable road user"), Patch(facecolor=GREY, label="Other class")],
          frameon=False, loc="lower right", handlelength=1.2)
clean(ax, axis="x"); fig.tight_layout(); save(fig, "Fig9_perclass_night_gain")
print("done")
