import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

W, H = 7.16, 3.15
fig = plt.figure(figsize=(W, H), dpi=300); ax = fig.add_axes([0,0,1,1]); ax.set_xlim(0,W); ax.set_ylim(0,H); ax.axis("off")
plt.rcParams["font.family"] = "DejaVu Sans"
T_FILL, S_FILL, IO, OURS, LOSS = "#5A5F73", "#0E1E3C", "#F2F2F2", "#EDEBFA", "#FBF1E3"
OURS_E, LOSS_E, IO_E, GREY = "#4A3DA6", "#B26A12", "#9A9A9A", "#444444"

def box(x, y, w, h, text, fill, edge=None, fc="black", fs=6.3, bold=False):
    ax.add_patch(FancyBboxPatch((x-w/2, y-h/2), w, h, boxstyle="round,pad=0,rounding_size=0.05",
                                fc=fill, ec=edge or fill, lw=0.8, zorder=3))
    if text:
        ax.text(x, y, text, ha="center", va="center", fontsize=fs, color=fc, zorder=4,
                fontweight="bold" if bold else "normal", linespacing=1.25)
def arrow(x1,y1,x2,y2, style="-", color=GREY, lw=0.8, rad=0.0):
    ax.add_patch(FancyArrowPatch((x1,y1),(x2,y2), arrowstyle="-|>", mutation_scale=7, lw=lw, color=color,
                                 linestyle=style, connectionstyle=f"arc3,rad={rad}", zorder=2, shrinkA=0, shrinkB=0))
def lane(x, y, w, h, title, col):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.06",
                                fc="none", ec=col, lw=0.7, ls=(0,(3,2)), zorder=1))
    ax.text(x+0.08, y+h-0.08, title, fontsize=6.2, color=col, ha="left", va="top", fontweight="bold", zorder=5)

yT, yS = 2.40, 1.05
bw, bh = 0.84, 0.42
xB, xN, xH = 1.28, 2.36, 3.44
lane(0.80, yT-0.36, 3.14, 0.82, "Teacher YOLOv8-L  (frozen, no gradient)", T_FILL)
lane(0.80, yS-0.36, 3.14, 0.82, "Student YOLOv8-S  (trainable)", S_FILL)

ym = (yT+yS)/2
box(0.36, ym, 0.56, 0.5, "Input\n640×640", IO, IO_E)
arrow(0.64, ym+0.06, xB-bw/2, yT-0.02, rad=-0.25)
arrow(0.64, ym-0.06, xB-bw/2, yS+0.02, rad=0.25)
for x, t in [(xB,"Backbone"),(xN,"Neck\nP3, P4, P5"),(xH,"Head\nclass logits, DFL")]:
    box(x, yT, bw, bh, t, T_FILL, fc="white"); box(x, yS, bw, bh, t, S_FILL, fc="white")
for yy in (yT, yS):
    arrow(xB+bw/2, yy, xN-bw/2, yy); arrow(xN+bw/2, yy, xH-bw/2, yy)

# loss column
xL, lw_ = 5.42, 1.18
yC, yR, yK = yT+0.10, ym, yS-0.06
box(xL, yC, lw_, 0.46, "$L_{CWD}$\nchannel-wise KL, τ = 4", OURS, OURS_E)
box(xL, yR, lw_, 0.78, "", LOSS, LOSS_E)
ax.text(xL, yR+0.17, "$L_{cls}$ + $L_{dfl}$\nKL on logits, T = 4 and 2", ha="center", va="center", fontsize=6.3, zorder=4, linespacing=1.25)
ax.text(xL, yR-0.20, "× w per anchor,\nw = √(teacher conf)", ha="center", va="center", fontsize=5.8, color=OURS_E, zorder=4, linespacing=1.2)
box(xL, yK, lw_, 0.46, "$L_{task}$\nYOLOv8 detection loss", LOSS, LOSS_E)

# adapter (feature path, purple)
xA, yA = 4.42, 1.36
box(xA, yA, 0.66, 0.34, "1×1 adapter", OURS, OURS_E)
arrow(xN+bw/2, yT+0.14, xL-lw_/2, yC+0.06, rad=-0.22, color=OURS_E)   # teacher neck -> CWD (over the head)
arrow(xN, yS+bh/2, xA-0.33, yA, rad=-0.28, color=OURS_E)               # student neck -> adapter (over the head)
arrow(xA+0.20, yA+0.17, xL-lw_/2, yC-0.12, rad=-0.28, color=OURS_E)   # adapter -> CWD
# response path (grey)
arrow(xH+bw/2, yT-0.10, xL-lw_/2, yR+0.22, rad=0.18)                   # teacher head -> Lresp
arrow(xH+bw/2, yS+0.10, xL-lw_/2, yR+0.02, rad=-0.18)                  # student head -> Lresp
# task path
arrow(xH+bw/2, yS-0.06, xL-lw_/2, yK+0.04)
box(xA, 0.40, 0.66, 0.30, "Ground truth", IO, IO_E, fs=6.0)
arrow(xA+0.33, 0.43, xL-lw_/2, yK-0.12, rad=0.15)

# total
xTOT = 6.62
box(xTOT, ym, 0.86, 1.30, "", LOSS, LOSS_E)
ax.text(xTOT, ym+0.20, "$L_{total}$ =\nα $L_{task}$\n+ β(t)($L_{cls}$+$L_{dfl}$)\n+ γ $L_{CWD}$", ha="center", va="center", fontsize=6.0, zorder=4, linespacing=1.3)
ax.text(xTOT, ym-0.42, "β(t): cosine decay\n0.35 → 0.10", ha="center", va="center", fontsize=5.6, color=OURS_E, zorder=4, linespacing=1.2)
for yy in [yC, yR, yK]:
    arrow(xL+lw_/2, yy, xTOT-0.43, yy)

# backprop
yb = 0.12
ax.plot([xTOT, xTOT, 1.0], [ym-0.65, yb, yb], color=S_FILL, lw=0.9, ls=(0,(3,2)), zorder=2)
arrow(1.0, yb, 1.0, yS-0.36, style=(0,(3,2)), color=S_FILL, lw=0.9)
ax.text(2.6, yb+0.04, "backpropagation to student and adapter only", fontsize=5.8, color=S_FILL,
        ha="center", va="bottom", bbox=dict(fc="white", ec="none", pad=0.4), zorder=5)
# legend
ax.plot([5.55,5.75],[0.52,0.52], color=OURS_E, lw=0.9); ax.text(5.80,0.52,"feature (CWD) path", fontsize=5.6, va="center", color=OURS_E)
ax.plot([5.55,5.75],[0.38,0.38], color=GREY, lw=0.9);   ax.text(5.80,0.38,"logit / task path", fontsize=5.6, va="center", color=GREY)

fig.savefig("Fig2_kd_framework.png", dpi=300, facecolor="white")
fig.savefig("Fig2_kd_framework.pdf", facecolor="white")
